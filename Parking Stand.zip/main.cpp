#include <iostream>
#include <string>
#include "Student.hpp"
#include "Teacher.hpp"
#include "Guest.hpp"
#include <vector>
#include <limits>
#include <fstream>
using namespace std;
// function prototype:

void displayTokenInfo(const std::string &role, int tokenNumber, const Person &person);

// main function:

int main()
{
    // variables declare:

    string fname;
    string lname;
    string idcard;
    int age;
    bool gender;
    char phone[12];
    int rollno;
    char department[25];
    int semester;
    string rank;
    int stdcard;
    int tchcard;
    int vehiclenum;
    int tokenNumber = 1;
    // menu variable:
    char menuChoice;
    // objects
    std::vector<Students> students;
    std::vector<Teachers> teachers;
    std::vector<Guest> guests;

    // Ask the user for Input M for the menu (First-menu)
    do
    {
        std::cout << "Enter 'M' for Menu: " << endl;
        std::cin >> menuChoice;
        cin.ignore();
        // condition that if user enter M/m it show menu otherwise no:
        if (menuChoice == 'M' || menuChoice == 'm')
        {
            // first option request:
            int option;
            std::cout << "1) Enter data" << std::endl;
            std::cout << "2) Remove Parking Car/Bike data" << std::endl;
            std::cout << "3) Check availability in Parking stand" << std::endl;
            std::cout << "Enter the number to select an option: ";
            std::cin >> option;
            

            switch (option)
            {
            case 1:
            {
                // 2nd option request:
                do
                {
                    int typeOption;
                    std::cout << "1) Teacher Data" << std::endl;
                    std::cout << "2) Student Data" << std::endl;
                    std::cout << "3) Guest/Visit person Data" << std::endl;
                    std::cout << "Enter the number to select the data type: ";
                    std::cin >> typeOption;

                    switch (typeOption)
                    {
                    case 1:
                    {
                        cout << "Enter the Data Of Respected Teacher :" << endl;

                        cout << "Enter the First-name :" << endl;
                        cin.ignore();
                        getline(cin, fname);
                        cout << "Enter the Last-name :" << endl;
                        getline(cin, lname);
                        cout << "Enter the ID-Card number :" << endl;
                        cin >> idcard;
                        cout << "Enter the Age :" << endl;
                        cin >> age;
                        cout << "Enter the Gender (1 for Male & 0 for Female) :" << endl;
                        cin >> gender;
                        cout << "Enter the Phone Number :" << endl;
                        cin >> phone;
                        cout << "Enter the Department :" << endl;
                        cin >> department;
                        cout << "Enter the Rank :" << endl;
                        cin >> rank;
                        cout << "Enter the Teacher Card :" << endl;
                        cin >> tchcard;
                        cout << "Enter the Vehicle Number :" << endl;
                        cin >> vehiclenum;
                        teachers.push_back(Teachers(fname, lname, age, idcard, gender, phone, department, rank, tchcard, vehiclenum));
                        std::ostringstream output;
                        Teachers Teacher(fname, lname, age, idcard, gender, phone, department, rank, tchcard, vehiclenum);
                        output << Teacher; // Assuming you have overloaded the << operator for the Teacher class
                        Teachers t;
                        // here data.txt is the file name
                        ofstream parkingstand("data.txt", ios::app | ios::ate);
                        if (parkingstand.is_open())
                        {
                            // Write the output string to the file
                            parkingstand << "Token :" << tokenNumber << "\n";
                            parkingstand << "Teacher card:" << tchcard << "\n";

                            parkingstand << output.str() << std::endl;
                            parkingstand << "Vehical_numer:" << vehiclenum << "\n";
                            parkingstand << "----------- " << std::endl;
                            parkingstand.close(); // Close the file
                        }
                        else
                        {
                            std::cerr << "Unable to open file";
                        }
                        break;
                    }
                    case 2:
                    {
                        cout << "Enter the Data of Talented Student :" << endl;

                        cout << "Enter the First-name :" << endl;
                        cin.ignore();
                        getline(cin, fname);
                        cout << "Enter the Last-name :" << endl;
                        getline(cin, lname);
                        cout << "Enter the ID-Card number :" << endl;
                        cin >> idcard;
                        cout << "Enter the Age :" << endl;
                        cin >> age;
                        cout << "Enter the Gender  (1 for Male & 0 for Female) :" << endl;
                        cin >> gender;
                        cout << "Enter the Phone Number :" << endl;
                        cin >> phone;
                        cout << "Enter the Department :" << endl;
                        cin >> department;
                        cout << "Enter the Semester :" << endl;
                        cin >> semester;
                        cout << "Enter the Roll no" << endl;
                        cin >> rollno;
                        cout << "Enter the Student Card :" << endl;
                        cin >> stdcard;
                        cout << "Enter the Vehicle Number :" << endl;
                        cin >> vehiclenum;
                        students.push_back(Students(fname, lname, age, idcard, gender, rollno, phone, department, semester, stdcard, vehiclenum));
                        std::ostringstream output;
                        Students Student(fname, lname, age, idcard, gender, rollno, phone, department, semester, stdcard, vehiclenum);
                        output << Student; // Assuming you have overloaded the << operator for the Students class
                        Students s;
                        ofstream parkingstand("data.txt", ios::app | ios::ate);
                        if (parkingstand.is_open())
                        {
                            // Write the output string to the file
                            parkingstand << "Token :" << tokenNumber << "\n";
                            parkingstand << "Student card:" << stdcard << "\n";

                            parkingstand << output.str() << std::endl;
                            parkingstand << "Vehical_numer:" << vehiclenum << "\n";
                            parkingstand << "----------- " << std::endl;
                            parkingstand.close(); // Close the file
                        }
                        else
                        {
                            std::cerr << "Unable to open file";
                        }
                        break;
                    }
                    case 3:
                    {
                        cout << "Enter the Data of Honourable Guest :" << endl;
                        cout << "Enter the First-name :" << endl;
                        cin.ignore();
                        getline(cin, fname);
                        cout << "Enter the Last-name :" << endl;
                        getline(cin, lname);
                        cout << "Enter the ID-Card number :" << endl;
                        cin >> idcard;
                        cout << "Enter the Age :" << endl;
                        cin >> age;
                        cout << "Enter the Gender  (1 for Male & 0 for Female) :" << endl;
                        cin >> gender;
                        cout << "Enter the Vehicle Number :" << endl;
                        cin >> vehiclenum;
                        guests.push_back(Guest(fname, lname, age, idcard, gender, vehiclenum));
                        std::ostringstream output;
                        Students Student(fname, lname, age, idcard, gender, rollno, phone, department, semester, stdcard, vehiclenum);
                        output << Student; // Assuming you have overloaded the << operator for the Students class
                        Students s;
                    
                        ofstream parkingstand("data.txt", ios::app | ios::ate);
                        if (parkingstand.is_open())
                        {
                            // Write the output string to the file
                            parkingstand << "Token :" << tokenNumber << "\n";
                            parkingstand << "Student card:" << stdcard << "\n";

                            parkingstand << output.str() << std::endl;
                            parkingstand << "Vehical_numer:" << vehiclenum << "\n";
                            parkingstand << "----------- " << std::endl;
                            parkingstand.close(); // Close the file
                        }
                        else
                        {
                            std::cerr << "Unable to open file";
                        }
                        break;
                    }
                    // ... (Other cases for different data types)
                    default:
                        std::cout << "Invalid option." << std::endl;
                    }

                    // Ask if the user wants to enter more data
                    char continueChoice;
                    // conditon check:

                    // fucntion call no need of much code like above :

                    // for student:
                    for (const auto &student : students)
                    {
                        displayTokenInfo("Student", tokenNumber++, student);
                    }
                    // for teacher
                    for (const auto &teacher : teachers)
                    {
                        displayTokenInfo("Teacher", tokenNumber++, teacher);
                    }
                    // for guest
                    for (const auto &guest : guests)
                    {
                        displayTokenInfo("Guest", tokenNumber++, guest);
                    }

                    // Function to display token information

                    cout << "Do you want to enter more data? (Y/N): ";
                    cin >> continueChoice;

                    // remove the buffer extra-spaces which causes by cin:

                    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore the rest of the line
                    if (continueChoice != 'Y' && continueChoice != 'y')
                    {
                        break;
                    }

                } while (true);
                break; // outer switch-cases end
            }
            // ... (Other cases remain the same)
            default:
                std::cout << "Invalid option." << std::endl;
                break;
            }
        } // end switch:

        else
        {
            std::cout << "Invalid input. Please enter 'M' for the menu." << std::endl;
        }

    } while (menuChoice == 'M' || menuChoice == 'm'); // loop end:

    return 0;
};

// Helper function to print out common token info
void displayTokenInfo(const std::string &role, int tokenNumber, const Person &person)
{
    if (tokenNumber < 10)
    {
        cout << "Token Ground Floor " << tokenNumber << " (" << role << "): " << person.display() << endl;
    }
    else if (tokenNumber < 20)
    {
        cout << "Token Basement Floor " << tokenNumber << " (" << role << "): " << person.display() << endl;
    }
    else if (tokenNumber < 30)
    {
        cout << "Token Floor " << tokenNumber << " (" << role << "): " << person.display() << endl;
    }
}
