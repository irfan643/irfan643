#include <iostream>
#include <string>
#include "Student.hpp"
#include "Teacher.hpp"
#include "Guest.hpp"
#include <vector>
#include <limits>
// for file
#include <fstream>
using namespace std;

// function prototype:
void displayTokenInfo(const std::string &role, int tokenNumber, const Person &person);
void deleteStudentRecord(int cardNumber);
int countTotalRecords(const std::string &filename);
bool isTokenNumberUnique(int tokenNumber, const std::string &filename);
void token_recordread(int searchCardNumber);
// make a global function to assign the token number automatically:
// int tokenNumber = 0;

int main()
{
    // variables declare:
    string fname;
    string lname;
    string idcard;
    int age;
    bool gender;
    char phone[12];
    int rollno;
    char department[25];
    int semester;
    string rank;
    int stdcard;
    int tchcard;
    int vehiclenum;
    int tokenNumber;
    // int limit;
    // menu variable:
    char menuChoice;
    // objects
    std::vector<Students> students;
    std::vector<Teachers> teachers;
    std::vector<Guest> guests;

    // Ask the user for Input M for the menu (First-menu)
    do
    {
        std::cout << "Enter 'M' for Menu: " << endl;
        std::cin >> menuChoice;
        cin.ignore();
        // condition that if user enter M/m it show menu otherwise no:
        if (menuChoice == 'M' || menuChoice == 'm')
        {
            // first option request:
            int option;
            std::cout << "1) Enter data" << std::endl;
            std::cout << "2) Remove Parking Car/Bike data " << std::endl;
            std::cout << "3) Total Vehicles in Parking " << std::endl;
            std::cout << "Enter the number to select an option: ";
            std::cin >> option;
            // tokenNumber++;

            switch (option)
            {
            case 1:
            {
                // 2nd option request:
                do
                {
                    int typeOption;
                    std::cout << "1) Teacher Data" << std::endl;
                    std::cout << "2) Student Data" << std::endl;
                    std::cout << "3) Guest/Visit person Data" << std::endl;
                    std::cout << "Enter the number to select the data type: ";
                    std::cin >> typeOption;

                    switch (typeOption)
                    {

                    case 1:
                    {
                        cout << "Enter the Data Of Respected Teacher :" << endl;

                        cout << "Enter the First-name :" << endl;
                        cin.ignore();
                        getline(cin, fname);
                        cout << "Enter the Last-name :" << endl;
                        getline(cin, lname);
                        cout << "Enter the ID-Card number :" << endl;
                        cin >> idcard;
                        cout << "Enter the Age :" << endl;
                        cin >> age;
                        cout << "Enter the Gender (1 for Male & 0 for Female) :" << endl;
                        cin >> gender;
                        cout << "Enter the Phone Number :" << endl;
                        cin >> phone;
                        cout << "Enter the Department :" << endl;
                        cin >> department;
                        cout << "Enter the Rank :" << endl;
                        cin >> rank;
                        cout << "Enter the Teacher Card :" << endl;
                        cin >> tchcard;
                        cout << "Enter the Vehicle Number :" << endl;
                        cin >> vehiclenum;

                        // Loop to get a unique token number
                        bool isUnique = false;
                        while (!isUnique)
                        {
                            cout << "Enter token Number" << endl;
                            cin >> tokenNumber;

                            // Check if the token number is unique before adding the new guest
                            if (isTokenNumberUnique(tokenNumber, "data.txt"))
                            {
                                isUnique = true; // Set the flag to true to exit the loop

                                // Add the new guest to the vector
                                teachers.push_back(Teachers(tokenNumber, fname, lname, age, idcard, gender, phone, department, rank, tchcard, vehiclenum));

                                // file handling Start:
                                // "ostringstream" function that change all data into string
                                std::ostringstream output;
                                // data goes to file
                                Teachers Teacher(tokenNumber, fname, lname, age, idcard, gender, phone, department, rank, tchcard, vehiclenum);
                                // object of string
                                output << Teacher;
                                ofstream parkingstand("data.txt", ios::app | ios::ate);
                                if (parkingstand.is_open())
                                {
                                    // Write the output string to the file
                                    parkingstand << "Token :" << tokenNumber << "\n";
                                    parkingstand << "Teacher card:" << tchcard << "\n";

                                    parkingstand << output.str() << std::endl;
                                    parkingstand << "Vehical_numer:" << vehiclenum << "\n";
                                    parkingstand << "----------- " << std::endl;
                                    parkingstand.close(); // Close the file
                                }
                                else
                                {
                                    std::cerr << "Unable to open file";
                                }
                            }
                            else
                            {
                                std::cout << "Token number " << tokenNumber << " is already in use. Please enter a different token number." << std::endl;
                            }
                        }

                        break;
                    }
                    case 2:
                    {
                        cout << "Enter the Data of Talented Student :" << endl;

                        cout << "Enter the First-name :" << endl;
                        cin.ignore();
                        getline(cin, fname);
                        cout << "Enter the Last-name :" << endl;
                        getline(cin, lname);
                        cout << "Enter the ID-Card number :" << endl;
                        cin >> idcard;
                        cout << "Enter the Age :" << endl;
                        cin >> age;
                        cout << "Enter the Gender  (1 for Male & 0 for Female) :" << endl;
                        cin >> gender;
                        cout << "Enter the Phone Number :" << endl;
                        cin >> phone;
                        cout << "Enter the Department :" << endl;
                        cin >> department;
                        cout << "Enter the Semester :" << endl;
                        cin >> semester;
                        cout << "Enter the Roll no" << endl;
                        cin >> rollno;
                        cout << "Enter the Student Card :" << endl;
                        cin >> stdcard;
                        cout << "Enter the Vehicle Number :" << endl;
                        cin >> vehiclenum;

                        // Loop to get a unique token number
                        bool isUnique = false;
                        while (!isUnique)
                        {
                            cout << "Enter token Number" << endl;
                            cin >> tokenNumber;

                            // Check if the token number is unique before adding the new guest
                            if (isTokenNumberUnique(tokenNumber, "data.txt"))
                            {
                                isUnique = true; // Set the flag to true to exit the loop

                                // Add the new guest to the vector
                                students.push_back(Students(tokenNumber, fname, lname, age, idcard, gender, rollno, phone, department, semester, stdcard, vehiclenum));

                                // Your existing code to write the new guest to the file
                                std::ostringstream output;
                                Students Student(tokenNumber, fname, lname, age, idcard, gender, rollno, phone, department, semester, stdcard, vehiclenum);
                                output << Student; // Assuming you have overloaded the << operator for the Guest class

                                ofstream parkingstand("data.txt", ios::app | ios::ate);
                                if (parkingstand.is_open())
                                {
                                    // Write the output string to the file
                                    parkingstand << "Token :" << tokenNumber << "\n";
                                    parkingstand << "Student card:" << stdcard << "\n";

                                    parkingstand << output.str() << std::endl;
                                    parkingstand << "Vehical_numer:" << vehiclenum << "\n";
                                    parkingstand << "----------- " << std::endl;
                                    parkingstand.close(); // Close the file
                                }
                                else
                                {
                                    std::cerr << "Unable to open file";
                                }
                            }
                            else
                            {
                                std::cout << "Token number " << tokenNumber << " is already in use. Please enter a different token number." << std::endl;
                            }
                        }

                        break;
                    }
                    case 3:
                    {
                        cout << "Enter the Data of Honourable Guest :" << endl;

                        // Your existing code to get guest details...
                        cout << "Enter the First-name :" << endl;
                        cin.ignore();
                        getline(cin, fname);
                        cout << "Enter the Last-name :" << endl;
                        getline(cin, lname);
                        cout << "Enter the ID-Card number :" << endl;
                        cin >> idcard;
                        cout << "Enter the Age :" << endl;
                        cin >> age;
                        cout << "Enter the Gender (1 for Male & 0 for Female) :" << endl;
                        cin >> gender;
                        cout << "Enter the Vehicle Number :" << endl;
                        cin >> vehiclenum;

                        // Loop to get a unique token number
                        bool isUnique = false;
                        while (!isUnique)
                        {
                            cout << "Enter token Number" << endl;
                            cin >> tokenNumber;

                            // Check if the token number is unique before adding the new guest
                            if (isTokenNumberUnique(tokenNumber, "data.txt"))
                            {
                                isUnique = true; // Set the flag to true to exit the loop

                                // Add the new guest to the vector
                                guests.push_back(Guest(tokenNumber, fname, lname, age, idcard, gender, vehiclenum));

                                // Your existing code to write the new guest to the file
                                std::ostringstream output;
                                Guest guest(tokenNumber, fname, lname, age, idcard, gender, vehiclenum);
                                output << guest; // Assuming you have overloaded the << operator for the Guest class

                                ofstream parkingstand("data.txt", ios::app | ios::ate);
                                if (parkingstand.is_open())
                                {
                                    // Write the output string to the file
                                    parkingstand << "Token :" << tokenNumber << "\n";
                                    parkingstand << output.str() << "\n";
                                    parkingstand << "Vehicle_numer:" << vehiclenum << "\n";
                                    parkingstand << "----------- " << std::endl;
                                    parkingstand.close(); // Close the file
                                }
                                else
                                {
                                    cerr << "Unable to open file" << endl;
                                }
                            }
                            else
                            {
                                std::cout << "Token number " << tokenNumber << " is already in use. Please enter a different token number." << std::endl;
                            }
                        }

                        break;
                    }
                    default:
                    {
                        std::cout << "Invalid option." << std::endl;
                    }
                    }

                    // Function to display token information
                    // fucntion call no need of much code like above :
                    // for student:
                    for (const auto &student : students)
                    {
                        cout << "Student Detail" << student.display() << endl;
                    }
                    // for teacher
                    for (const auto &teacher : teachers)
                    {
                        cout << "Teacher Detail" << teacher.display() << endl;
                    }
                    // for guest
                    for (const auto &guest : guests)
                    {
                        cout << "Guest Detail" << guest.display() << endl;
                        // displayTokenInfo("Guest", tokenNumber++, guest);
                    }

                    char continueChoice;
                    cout << "Do you want to enter more data? (Y/N): ";
                    cin >> continueChoice;

                    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore the rest of the line
                    // Increment tokenNumber only if the user wants to enter more data
                    if (continueChoice != 'Y' && continueChoice != 'y')
                    {
                        break;
                    }

                } while (true);
                break; // outer switch-cases end
            }
            case 2:
            {

                int valueinput;
                cout << "Enter your Choice " << endl;
                cout << "1) Show Token Detail :" << endl;
                cout << "2) Delete Token Record :" << endl;
                cin >> valueinput;
                switch (valueinput)
                {
                case 1:
                { /* code */
                    //  here code to show detail
                    int tokennumberchecker;
                    std::cout << "Enter the Token Card number you are looking for: ";
                    std::cin >> tokennumberchecker;

                    // Call token_recordread() from within main()
                    token_recordread(tokennumberchecker);
                    break;
                }
                case 2:
                {
                    int tokens;
                    cout << "Enter the Token Number " << endl;
                    cin >> tokens;
                    deleteStudentRecord(tokens);
                    break;
                }
                default:
                    cout << "You Enter wrong Choice" << endl;
                    break;
                }
            }
            case 3:
            {
                cout << "Total records in the file: " << countTotalRecords("data.txt") << endl;
                int countTotalRecords(const std::string &filename);
                break;
            }
            default:
                std::cout << "Invalid option." << std::endl;
                break;
            }
        } // end switch:
        else
        {
            std::cout << "Invalid input. Please enter 'M' for the menu." << std::endl;
        }

        // if(limit==3)
        // {
        //     break;
        // }
    } while (menuChoice == 'M' || menuChoice == 'm'); // loop end:

    return 0;
}

// Helper function to print out common token info
// Function to display token information
// void displayTokenInfo(const std::string &role, const Person &person)
// {

//         cout << "Person Detail" << person.display() << endl;

// }

void deleteStudentRecord(int tokenNumber)
{
    string line;
    ifstream file("data.txt");
    ofstream tempFile("temp.txt");

    bool found = false;
    bool skip = false;

    if (file.is_open() && tempFile.is_open())
    {
        while (std::getline(file, line))
        {
            // Check if the line contains the student card number
            // find is the function of string :

            //  search npos on internet:

            if (line.find("Token :" + std::to_string(tokenNumber)) != std::string::npos)
            {
                found = true;
                skip = true; // Start skipping lines related to this student
            }

            if (!skip)
            {
                tempFile << line << std::endl; // Write the line to the temporary file
            }
            else if (line.find("-----------") != std::string::npos)
            {
                skip = false; // Stop skipping lines when the separator is found
            }
        }
        file.close();
        tempFile.close();

        // Replace the original file with the temporary file
        remove("data.txt");
        rename("temp.txt", "data.txt");
    }
    else
    {
        std::cerr << "Unable to open file";
    }

    if (!found)
    {
        std::cout << "Student card number " << tokenNumber << " not found." << std::endl;
    }
    else
    {
        std::cout << "Student card number " << tokenNumber << " has been deleted." << std::endl;
    }
}

// function to count the line (---------)

int countTotalRecords(const std::string &filename)
{
    ifstream file(filename);
    string line;
    int recordCount = 0;
    bool inRecord = false;

    if (file.is_open())
    {
        while (std::getline(file, line))
        {
            // Check if the line is the start of a new record
            if (line.find("-----------") != std::string::npos)
            {
                inRecord = true;
                recordCount++; // Increment the record count
            }
            // If we're in a record and encounter a separator, it's the end of the record
            else if (inRecord && line.find("-----------") != std::string::npos)
            {
                inRecord = false;
            }
        }
        file.close();
    }
    else
    {
        std::cerr << "Unable to open file";
    }

    return recordCount;
}

// check that token number assign to person is unique or not:

bool isTokenNumberUnique(int tokenNumber, const std::string &filename)
{
    std::ifstream file(filename);
    std::string line;
    bool isUnique = true;

    if (file.is_open())
    {
        while (std::getline(file, line))
        {
            // Assuming each record starts with "Token :" followed by the token number
            if (line.find("Token :" + std::to_string(tokenNumber)) != std::string::npos)
            {
                isUnique = false;
                break;
            }
        }
        file.close();
    }
    else
    {
        std::cerr << "Unable to open file";
    }

    return isUnique;
}

// record Show:

void token_recordread(int tokennumberdata)
{
    std::string line;
    std::ifstream file("data.txt");
    bool found = false;

    if (file.is_open())
    {
        while (std::getline(file, line))
        {
            // Check if the line contains the token number
            if (line.find("Token :" + std::to_string(tokennumberdata)) != std::string::npos)
            {
                found = true;
                std::cout << "Found record with Token number " << tokennumberdata << ":\n"
                          << line << std::endl;

                // Continue reading and displaying lines until the "-----------" separator is found
                while (std::getline(file, line) && line.find("-----------") == std::string::npos)
                {
                    std::cout << line << std::endl;
                }
                break; // Exit the loop once the record's data is fully displayed
            }
        }

        file.close();

        if (!found)
        {
            std::cout << "Record with Token number " << tokennumberdata << " not found." << std::endl;
        }
    }
    else
    {
        std::cerr << "Unable to open file";
    }
}

