#include <iostream>
#include <vector>
#include <limits>
#include "Student.hpp"
#include "Teacher.hpp"

#include "Guest.hpp"

using namespace std;

// Function prototypes
void displayTokenInfo(const std::string &role, int tokenNumber, const Person &person);
void saveDataToFile(const std::vector<Students> &students, const std::vector<Teachers> &teachers, const std::vector<Guest> &guests);
void loadDataFromFile(std::vector<Students> &students, std::vector<Teachers> &teachers, std::vector<Guest> &guests);
void removeData(std::vector<Students> &students, std::vector<Teachers> &teachers, std::vector<Guest> &guests, int tokenNumber);

int main()
{
    char menuChoice;
    int tokenNumber = 1;

    std::vector<Students> students;
    std::vector<Teachers> teachers;
    std::vector<Guest> guests;

    do
    {
        cout << "Enter 'M' for Menu: " << endl;
        cin >> menuChoice;
        cin.ignore();

        if (menuChoice == 'M' || menuChoice == 'm')
        {
            int option;
            cout << "1) Enter data" << endl;
            cout << "2) Remove data" << endl;
            cout << "3) Check availability" << endl;
            cout << "Enter the number to select an option: ";
            cin >> option;

            switch (option)
            {
            case 1:
            {
                do
                {
                    int typeOption;
                    cout << "1) Teacher Data" << endl;
                    cout << "2) Student Data" << endl;
                    cout << "3) Guest Data" << endl;
                    cout << "Enter the number to select the data type: ";
                    cin >> typeOption;

                    switch (typeOption)
                    {
                    case 1:
                        teachers.emplace_back(); // Assuming default constructor exists for Teachers class
                        teachers.back().inputData();
                        break;

                    case 2:
                        students.emplace_back(); // Assuming default constructor exists for Students class
                        students.back().inputData();
                        break;

                    case 3:
                        guests.emplace_back(); // Assuming default constructor exists for Guest class
                        guests.back().inputData();
                        break;

                    default:
                        cout << "Invalid option." << endl;
                    }

                    // Save the data to the file after each data entry
                    saveDataToFile(students, teachers, guests);

                    // Display token information after each data entry
                    for (const auto &student : students)
                    {
                        displayTokenInfo("Student", tokenNumber++, student);
                    }
                    for (const auto &teacher : teachers)
                    {
                        displayTokenInfo("Teacher", tokenNumber++, teacher);
                    }
                    for (const auto &guest : guests)
                    {
                        displayTokenInfo("Guest", tokenNumber++, guest);
                    }

                    char continueChoice;
                    cout << "Do you want to enter more data? (Y/N): ";
                    cin >> continueChoice;

                    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                    if (continueChoice != 'Y' && continueChoice != 'y')
                    {
                        break;
                    }

                } while (true);

                break;
            }
            case 2:
            {
                int tokenToRemove;
                cout << "Enter the token number to remove: ";
                cin >> tokenToRemove;

                // Remove data based on the token number
                removeData(students, teachers, guests, tokenToRemove);

                // Save the updated data to the file
                saveDataToFile(students, teachers, guests);
                break;
            }
                // ... (Other cases remain the same)
            }

        }
        else
        {
            cout << "Invalid input. Please enter 'M' for the menu." << endl;
        }

    } while (menuChoice == 'M' || menuChoice == 'm');

    return 0;
}

// Function definitions
void displayTokenInfo(const std::string &role, int tokenNumber, const Person &person)
{
    if (tokenNumber < 10)
    {
        cout << "Token Ground Floor " << tokenNumber << " (" << role << "): " << person.display() << endl;
    }
    else if (tokenNumber < 20)
    {
        cout << "Token Basement Floor " << tokenNumber << " (" << role << "): " << person.display() << endl;
    }
    else if (tokenNumber < 30)
    {
        cout << "Token Floor " << tokenNumber << " (" << role << "): " << person.display() << endl;
    }
}

void saveDataToFile(const std::vector<Students> &students, const std::vector<Teachers> &teachers, const std::vector<Guest> &guests)
{
    // Implement this function to save data to a file
    // You can use ofstream and operator<< to serialize the data to a file
    // Make sure to handle any errors during file operations
}

void loadDataFromFile(std::vector<Students> &students, std::vector<Teachers> &teachers, std::vector<Guest> &guests)
{
    // Implement this function to load data from a file
    // You can use ifstream and operator>> to deserialize the data from a file
    // Make sure to handle any errors during file operations
}

void removeData(std::vector<Students> &students, std::vector<Teachers> &teachers, std::vector<Guest> &guests, int tokenNumber)
{
    auto removeIfTokenMatches = [tokenNumber](auto &container) {
        auto it = std::remove_if(container.begin(), container.end(), [tokenNumber](const auto &element) {
            return element.getTokenNumber() == tokenNumber;
        });
        container.erase(it, container.end());
    };

    removeIfTokenMatches(students);
    removeIfTokenMatches(teachers);
    removeIfTokenMatches(guests);
}
